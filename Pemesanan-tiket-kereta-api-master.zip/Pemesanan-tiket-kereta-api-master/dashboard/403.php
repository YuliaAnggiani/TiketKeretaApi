<?php
	include 'header.php';
	include 'sidebar.php';
	include 'navbar.php';
 ?>
<div class="jumbotron">
	<div class="text-danger bold text-center">
		<h2>403 Page forbidden</h2>
	</div>
</div>